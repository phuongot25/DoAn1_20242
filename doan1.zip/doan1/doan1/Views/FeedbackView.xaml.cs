﻿using System.Windows.Controls;

namespace RestaurantManagement.Views
{
    public partial class FeedbackView : UserControl
    {
        public FeedbackView()
        {
            InitializeComponent();
        }
    }
}
