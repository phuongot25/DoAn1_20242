﻿using System.Windows.Controls;

namespace RestaurantManagement.Views
{
    public partial class MenuView : UserControl
    {
        public MenuView()
        {
            InitializeComponent();
        }
    }
}
