﻿using System.Windows.Controls;

namespace RestaurantManagement.Views
{
    public partial class TableView : UserControl
    {
        public TableView()
        {
            InitializeComponent();
        }
    }
}
