﻿using System.Windows.Controls;

namespace RestaurantManagement.Views
{
    public partial class CustomerView : UserControl
    {
        public CustomerView()
        {
            InitializeComponent();
         
        }
    }
}
