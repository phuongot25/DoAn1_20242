﻿using System.Windows.Controls;

namespace RestaurantManagement.Views
{
    public partial class StaffView : UserControl
    {
        public StaffView()
        {
            InitializeComponent();
        }
    }
}
