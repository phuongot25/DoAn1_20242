﻿using System.Windows.Controls;

namespace RestaurantManagement.Views
{
    public partial class OrderView : UserControl
    {
        public OrderView()
        {
            InitializeComponent();
        }
    }
}
