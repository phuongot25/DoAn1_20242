﻿using System.Windows.Controls;

namespace RestaurantManagement.Views
{
    public partial class PromotionView : UserControl
    {
        public PromotionView()
        {
            InitializeComponent();
        }
    }
}
