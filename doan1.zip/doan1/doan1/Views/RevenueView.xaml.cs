﻿using System.Windows.Controls;

namespace RestaurantManagement.Views
{
    public partial class RevenueView : UserControl
    {
        public RevenueView()
        {
            InitializeComponent();
        }
    }
}
