﻿using System.Windows;

namespace RestaurantManagement
{
    public partial class App : Application
    {
    }
}
